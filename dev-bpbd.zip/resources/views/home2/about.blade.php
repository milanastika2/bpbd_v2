@extends('welcome2')

@section('latest')
				<h3>About Us</h3>
				{!! $Gsetting->about !!}

@stop