@extends('welcome2')

@section('latest')
				<h3>Sitemap </h3>
				{!! $Gsetting->sitemap !!}

@stop