@extends('welcome4')

@section('cat_feature')
				<h3>About Us</h3>
				{!! $Gsetting->about !!}

@stop