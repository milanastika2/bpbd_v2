@extends('welcome4')

@section('cat_feature')
				<h3>Sitemap </h3>
				{!! $Gsetting->sitemap !!}

@stop