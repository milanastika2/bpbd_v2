@extends('welcome4')

@section('cat_feature')
				<h3>Privacy</h3>
				{!! $Gsetting->privacy !!}

@stop