@extends('welcome')

@section('latest')
				<h3>Privacy</h3>
				{!! $Gsetting->privacy !!}

@stop