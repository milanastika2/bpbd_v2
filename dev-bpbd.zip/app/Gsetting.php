<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gsetting extends Model
{
    protected $guarded = [''];
}
