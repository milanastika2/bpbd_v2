<?php $__env->startSection('cat_feature'); ?>

<?php echo $seoComment->fbcomment; ?>


          <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="single-post">
            
            <div class="post-title-area">
              <a class="post-cat" href="#"><?php echo e($n->category->name); ?></a>
              <h2 class="post-title">
                <?php echo e($n->title); ?>

              </h2>
              <div class="post-meta">
                <span class="post-author">
                  By <a><?php echo e($n->user_name); ?></a>
                </span>   
                <span class="post-date"><i class="fa fa-clock-o"></i> <?php echo e($n->updated_at->toFormattedDateString()); ?></span>
                <span class="post-hits"><i class="fa fa-eye"></i> <?php echo e($n->hit_count); ?></span>
              </div>
            </div><!-- Post title end -->

            <div class="post-content-area">
              <div class="post-media post-featured-image">
              <a href="<?php echo e(asset('/images/'.$n->image)); ?>" class="gallery-popup cboxElement">
                <img src="<?php echo e(asset('/images/'.$n->image)); ?>" class="img-responsive" alt="">
                </a>
              </div>
              <div class="entry-content">
                <?php echo $n->details; ?>

              </div><!-- Entery content end -->

              <div class="tags-area clearfix">
                  <div class="post-tags">
                <?php $source=  $n->source; $tags = explode(',', $source); ?>
                  <span>Tags:</span>
                  <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($tag): ?><a href="#"> # <?php echo e($tag); ?> </a><?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div><!-- Tags end -->
              
    <div class="comments-form">
    <?php  $site = $seoComment->siteurl ?>
            <h3 class="title-normal">Leave a comment</h3>
      <div class="fb-comments" data-href="<?php echo e(url(''.$site.$n->id)); ?>" data-numposts="5"></div>
    </div><!-- Comments form end -->


          <div class="related-posts ">
            <h3 class="block-title"><span>Related Posts</span></h3>

            <div id="latest-news-slide" class="owl-carousel owl-theme latest-news-slide">

            <?php $__currentLoopData = $latestNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="item">
                <div class="post-block-style clearfix">
                  <div class="post-thumb">
                    <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>">
                    <img class="img-responsive" src="<?php echo e(asset('/images/'.$n->image)); ?>" alt="" /></a>
                  </div>
                  <div class="post-content">
                    <p class="post-title ">
                      <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>"><?php echo e($n->title); ?></a>
                    </p>
                    <div class="post-meta">
                      <span class="post-author"><a><?php echo e($n->user_name); ?></a></span>
                      <span class="post-date"><?php echo e($n->updated_at->toFormattedDateString()); ?></span>
                    </div>
                  </div><!-- Post content end -->
                </div><!-- Post Block style end -->
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div><!-- Carousel end -->
          </div><!-- Related posts end -->

              
            </div><!-- post-content end -->
          </div><!-- Single post end -->

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






<?php $__env->stopSection(); ?>


<div class="gap-40"></div>

<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>