<!DOCTYPE html>
<html lang="en">
<head>

	<!-- Basic Page Needs
	================================================== -->
	
  <title><?php echo e($Gsetting->title); ?></title>
  <meta name="keywords" content="<?php echo e($seoComment->metakeyword); ?>">
  <link rel="icon" href="<?php echo e(asset('public/images/'.$Gsetting->default_img)); ?>" type="image/x-icon">

	<!-- Mobile Specific Metas
	================================================== -->

	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

  
	<!-- CSS
	================================================== -->
  <!-- Bootstrap -->
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>">
<!-- Template styles-->
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/style.css')); ?>">
  <!-- Responsive styles-->
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/responsive.css')); ?>">    
  <!-- FontAwesome -->
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/font-awesome.min.css')); ?>">
  <!-- Animation -->
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/animate.css')); ?>">
  <!-- Owl Carousel -->
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/owl.carousel.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/owl.theme.default.min.css')); ?>">
  <!-- Colorbox -->
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/colorbox.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/css/sweetalert.css')); ?>">

<style type="text/css">
    .boxed-layout{
    background: #f7f7f7 url(<?php echo e(asset('public/images/boxed-bg.jpg')); ?>) no-repeat;
    background-position: center 0px;
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
}

</style>
</head>
	
<body class="boxed-layout">

	<div class="body-inner">

	<div id="top-bar" class="top-bar">
		<div class="container">
			<div class="row">
				<div class="col-md-7 col-sm-8 col-xs-12">
					<div class="ts-date">
						<i class="fa fa-calendar-check-o"></i>
						 <?php echo e(Carbon\Carbon::now()->toFormattedDateString()); ?>

					</div>
					<ul class="unstyled top-nav">
			            <li><a href="<?php echo e(url('/about-us')); ?>">About</a></li>
			            <li><a href="<?php echo e(url('/site-map')); ?>">Site Map</a></li>
			            <li><a href="<?php echo e(url('/privacy')); ?>">Privacy</a></li>
			            <li><a href="<?php echo e(url('/contact-us')); ?>">Contact</a></li>
					</ul>
				</div><!--/ Top bar left end -->

				<?php echo $__env->yieldContent('social-top'); ?>
				<?php echo $__env->yieldContent('search'); ?>
			</div><!--/ Content row end -->
		</div><!--/ Container end -->
	</div><!--/ Topbar end -->

	<!-- Header start -->
	<header id="header" class="header header-menu">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-3 col-md-3">
					<div class="logo">
						 <a href="<?php echo e(url('/')); ?>">
			              <img src="<?php echo e(asset('public/images/'.$Gsetting->logo)); ?>" alt="">
			             </a>
					</div>
				</div><!-- logo col end -->
				<?php echo $__env->make('home3.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				
			</div><!-- Row end -->
		</div><!-- Logo and banner area end -->
	</header><!--/ Header end -->

	<?php echo $__env->make('home3.breaking-news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<section class="featured-post-area no-padding">
		<div class="container">
			<div class="row">
				<?php echo $__env->yieldContent('slider'); ?>

			</div><!-- Row end -->
		</div><!-- Container end -->
	</section><!-- Trending post end -->

	<section class="block-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
				<?php echo $__env->yieldContent('left_add'); ?>

				<?php echo $__env->yieldContent('cat_feature'); ?>

				<?php echo $__env->yieldContent('add-leftSide'); ?>
				</div><!-- Content Col end -->

				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
					<div class="sidebar sidebar-right">
					<?php echo $__env->yieldContent('follow-us'); ?>

					<?php echo $__env->yieldContent('add-right'); ?>

					<div class="gap-30"></div>
					<?php echo $__env->yieldContent('popular'); ?>
					<div class="gap-30"></div>
					<?php echo $__env->yieldContent('tags'); ?>
					
					<?php echo $__env->yieldContent('subscriber'); ?>
					</div><!-- Sidebar right end -->
				</div><!-- Sidebar Col end -->

			</div><!-- Row end -->
		</div><!-- Container end -->
	</section><!-- First block end -->

	<?php echo $__env->yieldContent('categoryNews'); ?>

	<?php echo $__env->yieldContent('add-three'); ?>
	
	<footer id="footer" class="footer">
		<div class="footer-main">
			<div class="container">
				<div class="row">

					<div class="col-md-3 col-sm-12 footer-widget widget-categories">
						<h3 class="widget-title">Hot Categories</h3>
						<ul>
							<?php $__currentLoopData = $catMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li>
				                <a href="<?php echo e(url('/v/'.$cat->id.'/'.$cat->slug)); ?>">
				                  <span class="catTitle"><?php echo e($cat->name); ?></span>
				                  <span class="catCounter"> (<?php echo e($cat->posts()->count()); ?>)</span>
				                </a>
							</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
						
					</div><!-- Col end -->

					
          <div class="col-md-4  col-md-offset-1 col-sm-12 footer-widget twitter-widget">
            <h3 class="widget-title">Latest Videos</h3>
            <ul>
            <?php $__currentLoopData = $videoMenu->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
                <a href="<?php echo e(url('/videos/'.$n->id.'/'.$n->slug)); ?>">
                  <?php echo e(str_limit( $n->title, 60)); ?></a>
                </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div><!-- Col end -->

					<div class="col-md-3 col-sm-12 col-md-offset-1 footer-widget">
						<h3 class="widget-title">Post Gallery</h3>
						<div class="gallery-widget">
							<?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				              <a href="<?php echo e(asset('public/images/'.$n->image)); ?>" class="gallery-popup cboxElement">
				              <img class="img-responsive" src="<?php echo e(asset('public/images/'.$n->image)); ?>" alt="" />
				              </a>
				              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div><!-- Col end -->

				</div><!-- Row end -->
			</div><!-- Container end -->
		</div><!-- Footer main end -->

		<div class="footer-info text-center">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="footer-info-content">
							<div class="footer-logo">
			                	<img class="img-responsive" src="<?php echo e(asset('public/images/'.$Gsetting->logo)); ?>" alt="" />
			              	</div>
							
              <p class="footer-info-phone"><i class="fa fa-phone"></i> <?php echo e($Gsetting->phone); ?></p>
              <p class="footer-info-email"><i class="fa fa-envelope-o"></i> <?php echo e($Gsetting->email); ?></p>
							<?php echo $__env->yieldContent('social-footer'); ?>
						</div><!-- Footer info content end -->
					</div><!-- Col end -->
				</div><!-- Row end -->
			</div><!-- Container end -->
		</div><!-- Footer info end -->

	</footer><!-- Footer end -->


	
	<div class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-6">
						<div class="copyright-info">
							<span><?php echo e($Gsetting->footer); ?></span>
						</div>
					</div>

					<div class="col-xs-12 col-sm-6">
						<div class="footer-menu">
							<ul class="nav unstyled">
				              <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
			                  <li><a href="<?php echo e(url('/about-us')); ?>">About</a></li>
			                  <li><a href="<?php echo e(url('/site-map')); ?>">Site Map</a></li>
			                  <li><a href="<?php echo e(url('/privacy')); ?>">Privacy</a></li>
			                  <li><a href="<?php echo e(url('/contact-us')); ?>">Contact</a></li>
							</ul>
						</div>
					</div>
				</div><!-- Row end -->

				<div id="back-to-top" data-spy="affix" data-offset-top="10" class="back-to-top affix">
					<button class="btn btn-primary" title="Back to Top">
						<i class="fa fa-angle-up"></i>
					</button>
				</div>

			</div><!-- Container end -->
		</div><!-- Copyright end -->
	<!-- Javascript Files
	================================================== -->

	<!-- initialize jQuery Library -->
	<script type="text/javascript" src="<?php echo e(asset('public/assets/js/jquery.js')); ?>"></script>
	<!-- Bootstrap jQuery -->
	<script type="text/javascript" src="<?php echo e(asset('public/assets/js/bootstrap.min.js')); ?>"></script>
	
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>
	<!-- Owl Carousel -->
	<script type="text/javascript" src="<?php echo e(asset('public/assets/js/owl.carousel.min.js')); ?>"></script>
	<!-- Counter -->
	<script type="text/javascript" src="<?php echo e(asset('public/assets/js/jquery.counterup.min.js')); ?>"></script>
	<!-- Waypoints -->
	<script type="text/javascript" src="<?php echo e(asset('public/assets/js/waypoints.min.js')); ?>"></script>
	<!-- Color box -->
	<script type="text/javascript" src="<?php echo e(asset('public/assets/js/jquery.colorbox.js')); ?>"></script>
	<!-- Smoothscroll -->
	<script type="text/javascript" src="<?php echo e(asset('public/assets/js/smoothscroll.js')); ?>"></script>


	<!-- Template custom -->
	<script type="text/javascript" src="<?php echo e(asset('public/assets/js/custom.js')); ?>"></script>
	<script type="text/javascript">
    var path = "<?php echo e(route('autocomplete.ajax')); ?>";
    $('input.typeahead').typeahead({
        source:  function (query, process) {
        return $.get(path, { query: query }, function (data) {
                return process(data);
            });
        }
    });
</script>

  <?php echo $__env->make('Alerts::alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldContent('script'); ?>
	</div><!-- Body inner end -->
</body>

</html>