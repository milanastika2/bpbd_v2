<?php $__env->startSection('sub-title'); ?>
 | News
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-title'); ?>
	News

	<a href="<?php echo e(route('addnews')); ?>" type="button" class="pull-right btn  btn-info btn-flat"><i class="fa fa-plus"></i> <b>Add News Post</b> </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xs-12">
    	<div class="box">
            <div class="box-header">
              <!-- <h3 class="box-title"></h3> -->      
            <!-- /.box-header -->
            <div class="box-body">
              
                <table data-toggle="table"   data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
                    <thead>
                        <tr>
                            <th data-field="id" data-checkbox="true" ></th>
                            <th data-field="title" data-sortable="true" >News Title</th>
                            <th data-field="Category" data-sortable="true">News Category</th>
                            <th data-field="Details" data-sortable="true">News Details</th>
                            <th data-field="Status" data-sortable="true">Status </th>
                            <th data-field="Actions" data-sortable="true">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $allNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        	<td class="text-center"></td>
                            <td class=""><?php echo e($news->title); ?></td>
                         <td class=""> 
                            <?php
                              $d =  explode(',', $news->category_id); 
                            ?>

                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <b><?php if($cate == $c->id): ?> <?php echo e($c->name); ?>  <?php endif; ?></b>
        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                         </td>
                            <td class=""><?php echo str_limit(strip_tags($news->details),80); ?></td>
                            <td class="">
                            <?php if($news->status == 1) {?>
                            	<span class="label label-success">Published</span>
                                <?php } else { ?>
                                <span class="label label-warning">Unpublished</span>
                                <?php }?>
                            </td>
                            <td class="">
                            	<a class="btn btn-primary btn-xs" href="<?php echo e(url('/edit-news/'.$news->id)); ?>">
                                    <span class="glyphicon glyphicon-edit"></span>  Edit
                                </a>
                                <?php if($news->status == 1) {?>
                                <a class="btn btn-warning btn-xs" href="<?php echo e(url('/upb-news/'.$news->id)); ?>">
                                    <span class="glyphicon glyphicon-remove"></span>  Hide
                                </a>
                                <?php } else{ ?>
                                <a class="btn btn-success btn-xs" href="<?php echo e(url('/pb-news/'.$news->id)); ?>">
                                    <span class="glyphicon glyphicon-ok"></span>  Show
                                </a>
                                <?php }?>
                                <a class="btn btn-danger btn-xs" href="<?php echo e(url('/delete-news/'.$news->id)); ?>" onclick="return checkDelete()">
                                    <span class="glyphicon glyphicon-trash"></span>  Delete
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
	</div>
	<!-- /.col -->
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>