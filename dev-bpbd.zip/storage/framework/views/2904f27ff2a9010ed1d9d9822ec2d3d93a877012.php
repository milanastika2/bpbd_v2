
<?php $__env->startSection('sub-title'); ?>
 | Video
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-title'); ?>
Videos
  <a href="<?php echo e(route('addvideos')); ?>" type="button" class="pull-right btn  btn-info btn-flat"><i class="fa fa-plus"></i> <b>Add Videos </b> </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xs-12">
        
       
          <div class="box">
            <div class="box-header">
              
            </div>
            <div class="box-body">
              
                <table data-toggle="table"   data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
                    <thead>
                        <tr>
                            <th data-field="id" data-checkbox="true" ></th>
                            <th data-field="Video" data-sortable="true" >Video</th>
                            <th data-field="Title" data-sortable="true" >Video Title</th>
                            <th data-field="Status" data-sortable="true">Status </th>
                            <th data-field="Actions" data-sortable="true">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td class="text-center"></td>
                            <td class="">
                              <div class="videoWrapper">
                                  <?php echo $video->url; ?>

                              </div>
                            </td>
                         <td class=""><p><?php echo e($video->title); ?></p></td>
                            <td class="">
                              <?php if($video->status == 1) {?>
                              <span class="label label-success">Active</span>
                              <?php } else{ ?>
                              <span class="label label-warning">Deactive</span>
                              <?php }?>
                            </td>
                            </td>
                            <td class="">
                              <a class="btn btn-primary btn-xs" href="<?php echo e(url('/edit-videos/'.$video->id)); ?>">
                                    <span class="glyphicon glyphicon-edit"></span>  Edit
                                </a>
                                
                                <?php if($video->status == 1) {?>
                                <a class="btn btn-warning btn-xs" href="<?php echo e(url('/upb-videos/'.$video->id)); ?>">
                                    <span class="glyphicon glyphicon-remove"></span> Deactive 
                                </a>
                                <?php } else{ ?>
                                <a class="btn btn-success btn-xs" href="<?php echo e(url('/pb-videos/'.$video->id)); ?>">
                                    <span class="glyphicon glyphicon-ok"></span>  Active
                                </a>
                                <?php }?>

                                <a class="btn btn-danger btn-xs" href="<?php echo e(url('/delete-videos/'.$video->id)); ?>" onclick="return checkDelete()">
                                    <span class="glyphicon glyphicon-trash"></span>  Delete
                                </a>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
  </div>
  <!-- /.col -->
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>