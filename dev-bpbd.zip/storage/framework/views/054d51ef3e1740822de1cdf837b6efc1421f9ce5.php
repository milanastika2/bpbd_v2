<?php $__env->startSection('add-header'); ?>

<div class="col-xs-12 col-sm-9 col-md-9 header-right">
  <div class="ad-banner pull-right">
    <?php $__currentLoopData = $AddTop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(url('/click-add/'.$v->id)); ?>" target="_blank"> 
      <?php if($v->advert_type == 1): ?>
      <img class="img-responsive" src="<?php echo e(asset('public/images/'.$v->val1)); ?>" alt="" />
      <?php else: ?>
          <?php echo $v->val; ?>

      <?php endif; ?>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('add-leftSide'); ?>
  <div class="block ">
  <?php $__currentLoopData = $Addleft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(url('/click-add/'.$v->id)); ?>" target="_blank"> 
      <?php if($v->advert_type == 1): ?>
        <img class="img-responsive" src="<?php echo e(asset('public/images/'.$v->val1)); ?>" alt="" />
      <?php else: ?>
        <?php echo $v->val; ?>

      <?php endif; ?>
    </a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('add-three'); ?>
  <section class="ad-content-area text-center no-padding">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <?php $__currentLoopData = $Addvertise; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e(url('/click-add/'.$v->id)); ?>" target="_blank"> 
              <?php if($v->advert_type == 1): ?>
                <img class="img-responsive" src="<?php echo e(asset('public/images/'.$v->val1)); ?>" alt="" />
              <?php else: ?>
                <?php echo $v->val; ?>

              <?php endif; ?>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </section><br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('add-right'); ?>  
  <div class="widget text-center">
      <?php $__currentLoopData = $Addright; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('/click-add/'.$v->id)); ?>" target="_blank"> 
          <?php if($v->advert_type == 1): ?>
            <img class="img-responsive" src="<?php echo e(asset('public/images/'.$v->val1)); ?>" alt="" />
          <?php else: ?>
            <?php echo $v->val; ?>

          <?php endif; ?>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <br>
  <div class="widget text-center">
    <?php $__currentLoopData = $Addright2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('/click-add/'.$v->id)); ?>" target="_blank"> 
          <?php if($v->advert_type == 1): ?>
            <img class="img-responsive" src="<?php echo e(asset('public/images/'.$v->val1)); ?>" alt="" />
          <?php else: ?>
            <?php echo $v->val; ?>

          <?php endif; ?>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>