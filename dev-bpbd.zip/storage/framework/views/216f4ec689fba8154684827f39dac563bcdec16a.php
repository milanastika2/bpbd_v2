<?php $__env->startSection('article'); ?>
          
            <div class="widget color-default"> 
              <h3 class="block-title"><span>Artikel</span></h3>
              <div class="list-post-block">
                <ul class="list-post">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="clearfix">
                    <div class="post-block-style post-float clearfix">
                      <div class="post-thumb">
                        <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>">
                          <img class="img-responsive" src="<?php echo e(asset('/images/'.$n->image)); ?>" alt="" />
                        </a>
                        <a class="post-cat" href="<?php echo e(url('/v/'.$n->category->id.'/'.$n->category->name)); ?>"><?php echo e($n->category->name); ?></a>
                      </div><!-- Post thumb end -->

                      <div class="post-content">
                        <h2 class="post-title title-small">
                          <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>"><?php echo e(substr($n->title, 0, 50)); ?>... </a>
                        </h2>
                        <div class="post-meta">
                          <span class="post-date"><?php echo e($n->updated_at->toFormattedDateString()); ?></span>
                        </div>
                      </div><!-- Post content end -->
                    </div><!-- Post block style end -->
                  </li><!-- Li 1 end -->
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul><!-- List post end -->
              </div><!-- List post block end --> 
            </div><!-- Popular news widget end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>