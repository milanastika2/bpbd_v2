<?php $__env->startSection('cat_feature'); ?>

<div class="block category-listing category-style2">

	<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<h3 class="block-title"><span><?php echo e($cat->name); ?></span></h3>

		<?php $data=  $cat->posts()->paginate(8); ?>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="post-block-style post-list clearfix">
			<div class="row">
				
				<div class="col-md-5 col-sm-6">
					<div class="post-thumb thumb-float-style">
					<a href="<?php echo e(url('/v/'.$cat->id .'/'.$cat->slug.'/article/'.$n->id.'/'.$n->slug)); ?>">
					<img class="img-responsive" src="<?php echo e(asset('/images/'.$n->image)); ?>" alt="">
					</a>
					</div>
				</div><!-- Img thumb col end -->

				<div class="col-md-7 col-sm-6">
					<div class="post-content">
			 			<h2 class="post-title title-large">
			 				<a href="<?php echo e(url('/v/'.$cat->id .'/'.$cat->slug.'/article/'.$n->id.'/'.$n->slug)); ?>"><?php echo e(substr($n->title, 0, 100)); ?></a>
			 			</h2>
			 			<div class="post-meta">
			 				<span class="post-author"><a><?php echo e($n->user_name); ?></a></span>
				 			<span class="post-date"><?php echo e($n->updated_at->toFormattedDateString()); ?></span>
			 			</div>
			 			<p><?php echo str_limit(strip_tags($n->details),200); ?></p>
		 			</div><!-- Post content end -->
				</div><!-- Post col end -->
			</div><!-- 1st row end -->
		</div><!-- 1st Post list end -->
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="text-center"><?php echo $data->links('layouts.pagination'); ?></div> 

<?php $__env->stopSection(); ?>




<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>