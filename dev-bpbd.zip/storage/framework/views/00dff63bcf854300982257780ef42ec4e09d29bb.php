<?php $__env->startSection('slider'); ?>
    <div class="col-md-12 col-xs-12 pad-r">  
        <div id="featured-slider" class="owl-carousel owl-theme featured-slider" style="height: auto; max-height: 350px;">
            <?php if($slider): ?>
                <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                      <img src="<?php echo e(asset('/uploads/slider/'.$n->image)); ?>" style="height: auto; max-height: 350px;">
                    </div><!-- Item 2 end -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div><!-- Featured owl carousel end-->
    </div><!-- Col 6 end --> 

    
    
        
        
        
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>