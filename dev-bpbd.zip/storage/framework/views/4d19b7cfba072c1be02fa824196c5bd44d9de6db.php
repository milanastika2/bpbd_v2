
<?php $__env->startSection('subscriber'); ?>

      <div class="widget m-bottom-0">
        <h3 class="block-title"><span>Newsletter</span></h3>
        <div class="ts-newsletter">
          <div class="newsletter-introtext">
            <h4>Get Updates</h4>
            <p>Subscribe our newsletter to get the best stories into your inbox!</p>
          </div>

          <div class="newsletter-form">
            <form action="<?php echo e(route('subscribe')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

              <div class="form-group">
                <input type="email" name="email" id="newsletter-form-email" class="form-control form-control-lg" placeholder="E-mail" autocomplete="on">
                <button class="btn btn-primary">Subscribe</button>
              </div>
            </form>
          </div>

          <?php if(Session::get('error')): ?>
            <div class="alert alert-error">
              <?php echo e(Session::get('error')); ?>

            </div>
          <?php endif; ?>
        </div><!-- Newsletter end -->

        <?php echo $__env->make('errors.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div><!-- Newsletter widget end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Alerts::alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
  $(".alert").delay(10000).slideUp(300, function() {
       $(this).alert('close');
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>