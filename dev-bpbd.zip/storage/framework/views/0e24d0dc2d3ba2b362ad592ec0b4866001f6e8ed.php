<?php $__env->startSection('follow-us'); ?> 
  <div class="widget">
  <h3 class="block-title"><span>Follow Us</span></h3>
  <ul class="social-icon">
  <?php $__currentLoopData = $Social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e($s->link); ?>" target="_blank"><?php echo $s->code; ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
  <div class="list-post-block">
    <img src="<?php echo e(asset('/images/bannergubwagub_kominfo01.png')); ?>" alt="bali" class="img-responsie">  
  </div>
  <br>
</div><!-- Widget Social end -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('social-top'); ?>
        <div class="col-md-4 col-sm-4 col-xs-12 top-social text-right">
          <ul class="unstyled">
            <li>
              <?php $__currentLoopData = $Social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a title="<?php echo e($s->name); ?>" href="<?php echo e($s->link); ?>" target="_blank">
                <span class="social-icon"><?php echo $s->code; ?></span>
              </a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </li>
          </ul><!-- Ul end -->
        </div><!--/ Top social col end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('social-footer'); ?>
    <ul class="unstyled footer-social">
      <li>
      <?php $__currentLoopData = $Social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a title="<?php echo e($s->name); ?>" href="<?php echo e($s->link); ?>" target="_blank">
          <span class="social-icon"><?php echo $s->code; ?></span>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </li>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>