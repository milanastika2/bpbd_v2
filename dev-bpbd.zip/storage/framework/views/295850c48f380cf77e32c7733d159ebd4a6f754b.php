
<?php $__env->startSection('categoryNews'); ?>
  <section class="block-wrapper">
    <div class="container">
      <div class="row">

       <?php $__currentLoopData = $catNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4" style="margin-bottom: 25px;">
          <div class="block color-red">
            <a href="<?php echo e(url('/v/'.$cat->id.'/'.$cat->slug)); ?>">
            <h3 class="block-title">
            <span><?php echo e($cat->name); ?></span>
            </h3></a>
            
            <div class="list-post-block">
              <ul class="list-post">
              <?php $__currentLoopData = $cat->posts()->take(4)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="clearfix">
                  <div class="post-block-style post-float clearfix">
                    <div class="post-thumb">
                    <?php if($n->image): ?>
                      <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>">
                        <img class="img-responsive" src="<?php echo e(asset('public/images/'.$n->image)); ?>" alt="" />
                      </a>
                      <?php endif; ?>
                    </div><!-- Post thumb end -->

                    <div class="post-content">
                      <h2 class="post-title title-small">
                        <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>"><?php echo e($n->title); ?></a>
                      </h2>
                      <div class="post-meta">
                        <span class="post-date"><?php echo e($n->updated_at->toFormattedDateString()); ?></span>
                      </div>
                    </div>
                  </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </ul>
            </div>

          </div>
        </div>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div><!-- Row end -->
    </div><!-- Container end -->
  </section><!-- 2nd block end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>