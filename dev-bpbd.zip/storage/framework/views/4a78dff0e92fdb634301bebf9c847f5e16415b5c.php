

<?php $__env->startSection('latest'); ?>
     
<div class="latest-news block color-red">
  <h3 class="block-title"><span>Latest News</span></h3>
  <div id="latest-news-slide" class="owl-carousel owl-theme latest-news-slide">
  <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="item">
          <div class="post-block-style clearfix">
            <div class="post-thumb">
              <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>"><img class="img-responsive" src="<?php echo e(asset('public/images/'.$n->image)); ?>" alt="" /></a>
            </div>
            <a class="post-cat" href="<?php echo e(url('/v/'.$n->category->id.'/'.$n->category->slug)); ?>"><?php echo e($n->category->name); ?></a>
            <div class="post-content">
              <h2 class="post-title title-medium">
                <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>"><?php echo e($n->title); ?></a>
              </h2>
              <div class="post-meta">
                <span class="post-author"><a ><?php echo e($n->user_name); ?></a></span>
                <span class="post-date"><?php echo e($n->updated_at->toFormattedDateString()); ?></span>
              </div>
            </div><!-- Post content end -->
          </div><!-- Post Block style end -->
    </div><!-- Item 1 end -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div><!-- Latest News owl carousel end-->
</div><!--- Latest news end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>