
  <div class="trending-light hidden-xs">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h3 class="trending-title">Breaking News</h3>
          <div id="trending-slide" class="owl-carousel owl-theme trending-slide">
          <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
               <div class="post-content">
                  <h2 class="post-title title-small">
                     <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>"><?php echo e($n->title); ?></a>
                  </h2>
               </div><!-- Post content end -->
            </div><!-- Item 1 end -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div><!-- Carousel end -->
        </div><!-- Col end -->
      </div><!--/ Row end -->
    </div><!--/ Container end -->
  </div><!--/ Trending light end -->