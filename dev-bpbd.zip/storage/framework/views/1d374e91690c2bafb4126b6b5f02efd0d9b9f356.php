

<?php $__env->startSection('latest'); ?>
				<h3>Sitemap </h3>
				<?php echo $Gsetting->sitemap; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>