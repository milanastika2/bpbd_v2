<?php $__env->startSection('menubar'); ?>
<style type="text/css">
  .sidebar ul li.active{
    background: red;
  }
</style>

<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar" >
      <ul class="sidebar-menu " >
<!--<li class="<?php echo e(url()->current() == url('/')?'active':''); ?>" > home </li>-->

<?php 
        if(Sentinel::check() && Sentinel::getUser()->roles()->first()->slug=='manager'){
      ?>
      <li  class="<?php echo e(url()->current() == url('/manager')?'active':''); ?>">
          <a href="<?php echo e(URL::to('/manager')); ?>"><i class="fa fa-home"></i> <span>Dashboard</span> </a>
      </li>
<?php }elseif(Sentinel::check() && Sentinel::getUser()->roles()->first()->slug=='admin'){
      ?>
      <li  class="<?php echo e(url()->current() == url('/admin')?'active':''); ?>">
          <a href="<?php echo e(URL::to('/admin')); ?>"><i class="fa fa-home"></i> <span> Dashboard</span> </a>
      </li>
<?php }?>


<?php 
         if(Sentinel::check() && Sentinel::getUser()->roles()->first()->slug=='manager'){
      ?>
    <li class="<?php echo e(url()->current() == route('news')?'active':''); ?>">
      <a href="<?php echo e(route('news')); ?>"><i class="fa fa-newspaper-o"></i> <span>News</span></a></li>
    
    <!-- <li class="<?php echo e(url()->current() == route('gallery')?'active':''); ?>">
      <a href="<?php echo e(route('gallery')); ?>"><i class="fa fa-camera"></i> <span>Image Gallery</span></a></li> -->
    <li class="<?php echo e(url()->current() == route('videos')?'active':''); ?>">
      <a href="<?php echo e(route('videos')); ?>"><i class="fa fa-film"></i> <span>Videos</span></a></li>
    <li class="<?php echo e(url()->current() == route('subscribers')?'active':''); ?>">
     <a href="<?php echo e(route('subscribers')); ?>"><i class="fa fa-users"></i> <span>Subscribers</span></a></li>
  <?php } ?>   


<?php 
         if(Sentinel::check() && Sentinel::getUser()->roles()->first()->slug=='admin'){
      ?>

    <li class="<?php echo e(url()->current() == route('category')?'active':''); ?>">
      <a href="<?php echo e(route('category')); ?>"><i class="fa fa-sitemap"></i> <span>Category</span></a></li>
      
    <li class="<?php echo e(url()->current() == route('news')?'active':''); ?>">
      <a href="<?php echo e(route('news')); ?>"><i class="fa fa-newspaper-o"></i> <span>News</span></a></li>
<!-- 
    <li class="<?php echo e(url()->current() == route('mediaGallery')?'active':''); ?>">
    <a href="<?php echo e(route('mediaGallery')); ?>"><i class="fa fa-photo"></i> <span>Media Library</span></a></li>

    <li class="<?php echo e(url()->current() == route('gallery')?'active':''); ?>">
      <a href="<?php echo e(route('gallery')); ?>"><i class="fa fa-camera"></i> <span>Image Gallery</span></a></li> -->

    <li class="<?php echo e(url()->current() == route('videos')?'active':''); ?>">
      <a href="<?php echo e(route('videos')); ?>"><i class="fa fa-film"></i> <span>Videos</span></a></li>
  
    <li class="<?php echo e(url()->current() == route('staffs')?'active':''); ?>">
      <a href="<?php echo e(route('staffs')); ?>"><i class="fa fa-user"></i> <span>Staffs</span></a></li>

    <li class="<?php echo e(url()->current() == route('social')?'active':''); ?>">
      <a href="<?php echo e(route('social')); ?>"><i class="fa fa-paper-plane"></i> <span>Social Settings</span></a></li>

    <li class="<?php echo e(url()->current() == route('advertise')?'active':''); ?>">
      <a href="<?php echo e(route('advertise')); ?>"><i class="fa fa-link"></i> <span>Advertisements</span></a></li>
<li class="<?php echo e(url()->current() == route('subscribers')?'active':''); ?>">
     <a href="<?php echo e(route('subscribers')); ?>"><i class="fa fa-users"></i> <span>Subscribers</span></a></li>
     
    <li class="<?php echo e(url()->current() == route('seo')?'active':''); ?>">
      <a href="<?php echo e(route('seo')); ?>"><i class="fa fa-wrench"></i> <span>Seo Tools</span></a></li>

    <li class="<?php echo e(url()->current() == route('gsettings')?'active':''); ?>">
      <a href="<?php echo e(route('gsettings')); ?>"><i class="fa fa-cogs"></i> <span>General Settings</span></a></li>

    <li class="<?php echo e(url()->current() == route('themeChoose')?'active':''); ?>">
    <a href="<?php echo e(route('themeChoose')); ?>"><i class="fa fa-paint-brush"></i> <span>Theme Option</span></a></li>
    <?php }?>   
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>