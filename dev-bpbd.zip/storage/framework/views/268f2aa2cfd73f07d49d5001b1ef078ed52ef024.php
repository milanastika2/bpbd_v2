@extend('welcome2')

<?php $__env->startSection('cat_feature'); ?>
          
          <?php $__currentLoopData = $catNews2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="block color-black">
            <a href="<?php echo e(url('/v/'.$cat->id.'/'.$cat->slug)); ?>">
              <h3 class="block-title"><span><?php echo e($cat->name); ?></span></h3>
            </a>
              <div class="row">

              <?php $__currentLoopData = $cat->posts()->take(2)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-sm-6" style="margin-bottom: 20px;">
                <div class="post-overaly-style clearfix">
                  <div class="post-thumb">
                    <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>">
                    <img class="img-responsive" src="<?php echo e(asset('public/images/'.$n->image)); ?>" alt="">
                    </a>
                  </div>
                  <div class="post-content">
                    <!-- <a class="post-cat" href="#">Travel</a> -->
                    <h2 class="post-title">
                      <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>"><?php echo e($n->title); ?></a>
                    </h2>
                    <div class="post-meta">
                      <span class="post-date"><?php echo e($n->updated_at->toFormattedDateString()); ?></span> 
                    </div>
                  </div>
                </div>

              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div><!-- Row end -->
          </div>
          <div class="gap-40"></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
