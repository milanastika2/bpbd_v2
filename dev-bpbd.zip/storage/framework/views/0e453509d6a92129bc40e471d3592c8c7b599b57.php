<?php $__env->startSection('cuacaToday'); ?>
<section class="block-wrapper cuacaToday">
    <div class="container">
      	<div class="row"> 
      		<div class="col-md-8" style="margin-bottom: 25px;">
      			<div class="block color-red">
		            <a href="#">
		              <h3 class="block-title">
		                <span>Informasi <?php echo e($title_info); ?></span>
		              </h3>
		            </a>
		        </div>
		        <?php echo $peringatanCuacaTerkini; ?>

		        <p><u><em>Sumber :  BMKG</em></u></p>
		        <hr>
	    	</div>
      	</div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>