

<?php $__env->startSection('slider'); ?>


  <div class="col-md-7 col-xs-12 pad-r">
    <div id="featured-slider" class="owl-carousel owl-theme featured-slider">
    <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="item" style="background-image:url(<?php echo e(asset('public/images/'.$n->image)); ?>)">
        <div class="featured-post">
          <div class="post-content">
            <a class="post-cat" href="<?php echo e(url('/v/'.$n->category->id.'/'.$n->category->slug)); ?>"><?php echo e($n->category->name); ?></a>
            <h2 class="post-title title-extra-large">
              <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>"><?php echo e($n->title); ?></a>
            </h2>
            <span class="post-date"><?php echo e($n->updated_at->toFormattedDateString()); ?></span>
          </div>
        </div><!--/ Featured post end -->
      </div><!-- Item 1 end -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div><!-- Featured owl carousel end-->
  </div><!-- Col 7 end -->

        <div class="col-md-5 col-xs-12 pad-l">
          <div class="row">
            <?php $__currentLoopData = $slider2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-sm-12">
                <div class="post-overaly-style contentTop hot-post-top clearfix">
                  <div class="post-thumb">
                    <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>">
                      <img class="img-responsive" src="<?php echo e(asset('public/images/'.$n->image)); ?>" alt="" />
                    </a>
                  </div>
                  <div class="post-content">
                    <a class="post-cat" href="<?php echo e(url('/v/'.$n->category->id.'/'.$n->category->slug)); ?>"><?php echo e($n->category->name); ?></a>
                    <h2 class="post-title title-large">
                      <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>"><?php echo e($n->title); ?></a>
                    </h2>
                    <span class="post-date"><?php echo e($n->updated_at->toFormattedDateString()); ?></span>
                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $slider3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 pad-r-small">
              <div class="post-overaly-style contentTop hot-post-bottom clearfix">
                <div class="post-thumb">
                  <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>">
                  <img class="img-responsive" src="<?php echo e(asset('public/images/'.$n->image)); ?>" alt="" />
                  </a>
                </div>
                <div class="post-content">
                  <a class="post-cat" href="<?php echo e(url('/v/'.$n->category->id.'/'.$n->category->slug)); ?>"><?php echo e($n->category->name); ?></a>
                  <h2 class="post-title title-medium">
                    <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>"><?php echo e($n->title); ?></a>
                  </h2>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>