

<?php $__env->startSection('slider'); ?>

        <div class="col-md-6 col-xs-12 pad-r">
          <div id="featured-slider" class="owl-carousel owl-theme featured-slider">
            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item" style="background-image:url(<?php echo e(asset('public/images/'.$n->image)); ?>)">
              <div class="featured-post">
                <div class="post-content">
                  <a class="post-cat" href="<?php echo e(url('/v/'.$n->category->id.'/'.$n->category->slug)); ?>"><?php echo e($n->category->name); ?></a>
                  <h2 class="post-title title-extra-large">
                    <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>"><?php echo e($n->title); ?></a>
                  </h2>
                  <span class="post-date"><?php echo e($n->updated_at->toFormattedDateString()); ?></span>
                </div>
              </div><!--/ Featured post end -->
            </div><!-- Item 2 end -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div><!-- Featured owl carousel end-->
        </div><!-- Col 6 end -->

        <div class="col-md-6 col-xs-12 pad-l">
          <div class="row">

            <?php $__currentLoopData = $slider->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 pad-r-small">
              <div class="post-overaly-style contentTop fourNewsboxTop clearfix">
                <div class="post-thumb">
                  <a href="#">
                  <img class="img-responsive" src="<?php echo e(asset('public/images/'.$n->image)); ?>" alt=""/></a>
                </div>
                <div class="post-content">
                  <a class="post-cat" href="<?php echo e(url('/v/'.$n->category->id.'/'.$n->category->slug)); ?>"><?php echo e($n->category->name); ?></a>
                  <h2 class="post-title title-medium">
                    <a href="<?php echo e(url('/article/'.$n->id.'/'.$n->slug)); ?>"><?php echo e($n->title); ?></a>
                  </h2>
                </div><!-- Post content end -->
              </div><!-- Post Overaly end -->
            </div><!-- Col end -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div><!-- Row end -->
        </div><!-- Col 6 end -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>