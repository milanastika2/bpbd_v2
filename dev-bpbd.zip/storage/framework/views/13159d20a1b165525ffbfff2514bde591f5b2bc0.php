
<?php $__env->startSection('sub-title'); ?>
  | Staff
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-title'); ?>
	Edit Staff

	<a href="<?php echo e(route('staffs')); ?>" type="button" class="pull-right btn  btn-primary btn-flat"><i class="glyphicon glyphicon-arrow-left"></i> <b>Back</b> </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xs-10 col-xs-offset-1">
    		
       <div class="box box-info">
            <div class="box-header with-border">
              

            <?php if(Session::get('error')): ?>
              <div class="alert alert-error">
                <?php echo e(Session::get('error')); ?>

              </div>
            <?php endif; ?>
            </div>
            <!-- /.box-header -->
            <form class="form-horizontal" name="editStaff" action="<?php echo e(route('updatestaffs')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

              <div class="box-body">
               <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-3 control-label">First Name *</label>
                  <div class="col-sm-8">
                    <input type="text" name="first_name" class="form-control" value="<?php echo e($user->first_name); ?>">
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-3 control-label">Last Name *</label>
                  <div class="col-sm-8">
                    <input type="text" name="last_name" class="form-control" value="<?php echo e($user->last_name); ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-3 control-label">Staff Email *</label>
                  <div class="col-sm-8">
                    <input type="email" value="<?php echo e($user->email); ?>" name="email" class="form-control">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-3 control-label">Staff Phone *</label>
                  <div class="col-sm-8">
                    <input type="tel"  name="phone" value="<?php echo e($user->phone); ?>" class="form-control">
                  </div>
                </div>
                    
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-success col-sm-8 col-sm-offset-3">Update  </button>
              </div>
              <!-- /.box-footer -->
            </form>



        <br>
        <div class="box box-info">
            <div class="box-header with-border">
            </div>
            <div class="box-body">
            <form action="<?php echo e(route('updateRole')); ?>" method="post" role="form" class="form-horizontal" >
            <?php echo e(csrf_field()); ?>

              <legend>Role Field</legend>
                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-3 control-label">Select Role *</label>
                  <div class="col-sm-8">
                    <select name="role" class="form-control" required>
                    <option value="">Select Role</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
          </div>
          <div class="box-footer">
                <button type="submit" class="btn btn-success col-sm-8 col-sm-offset-3">Update Role  </button>
              </div>
          </div>
          </form>



        <br>
        <div class="box box-info">
            <div class="box-header with-border">
            </div>
            <div class="box-body">
            <form action="<?php echo e(route('updatePass')); ?>" method="post" role="form" class="form-horizontal">
            <?php echo e(csrf_field()); ?>

              <legend>Password Field</legend>
            
            <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
              <div class="form-group">
                  <label for="inputEmail3" class="col-sm-3 control-label">Password *</label>
                  <div class="col-sm-8">
                    <input type="password" name="password" class="form-control" >
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-3 control-label">Confirm Password *</label>
                  <div class="col-sm-8">
                    <input type="password"  name="password_confirmation" class="form-control" >
                  </div>
                </div>
              
          </div>
          <div class="box-footer">
                <button type="submit" class="btn btn-success col-sm-8 col-sm-offset-3">Change Password  </button>
              </div>
          </div>

            </form>
         
	</div>
	<!-- /.col -->
</div>
<script type="text/javascript">
  // document.forms['editStaff'].elements['role'].value=<?php echo e($role->id); ?>

</script>
<!-- /.row -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>